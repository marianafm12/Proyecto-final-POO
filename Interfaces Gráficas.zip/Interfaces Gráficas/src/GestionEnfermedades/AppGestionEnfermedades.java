package GestionEnfermedades;

public class AppGestionEnfermedades {/*
                                      * public static void main(String[] args) {
                                      * LoginFrame.main(args);
                                      * }
                                      */
}
