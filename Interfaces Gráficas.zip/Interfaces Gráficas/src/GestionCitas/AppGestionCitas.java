package GestionCitas;

public class AppGestionCitas {
    public static void main(String[] args) {
        new InicioFrame();
    }
}
