package GestionCitas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

public class ModificarCitaFrame extends JFrame {

    private JTextField nombreField, idField;
    private JLabel errorLabel;
    private JComboBox<Integer> diaBox, añoBox;
    private JComboBox<String> mesBox, horaBox, minutoBox;

    public ModificarCitaFrame() {
        setTitle("Modificar Cita");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        setLocationRelativeTo(null);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        JLabel title = new JLabel("Modificar Cita Médica", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        add(title, gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        nombreField = new JTextField(12);
        add(nombreField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        idField = new JTextField(12);
        add(idField, gbc);
        // Selección de cita a modificar
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Selecciona tu cita:"), gbc);

        gbc.gridx = 1;
        String[] citas = { "Cita X" };
        JComboBox<String> citaBox = new JComboBox<>(citas);
        add(citaBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Nueva Fecha:"), gbc);

        gbc.gridx = 1;
        String[] meses = { "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" };
        mesBox = new JComboBox<>(meses);
        diaBox = new JComboBox<>();
        añoBox = new JComboBox<>();

        for (int i = 1; i <= 31; i++)
            diaBox.addItem(i);
        for (int i = LocalDate.now().getYear(); i <= 2030; i++)
            añoBox.addItem(i);

        JPanel fechaPanel = new JPanel();
        fechaPanel.add(diaBox);
        fechaPanel.add(mesBox);
        fechaPanel.add(añoBox);
        add(fechaPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("Hora de la Cita:"), gbc);

        // JComboBox para hora
        gbc.gridx = 0;
        String[] horas = { "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21" };
        horaBox = new JComboBox<>(horas);
        // JComboBox para minutos
        gbc.gridx = 1;
        String[] minutos = { "00", "30" };
        minutoBox = new JComboBox<>(minutos);

        JPanel horaPanel = new JPanel();
        horaPanel.add(horaBox);
        horaPanel.add(minutoBox);
        add(horaPanel, gbc);

        errorLabel = new JLabel("", SwingConstants.CENTER);
        errorLabel.setForeground(Color.RED);
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        add(errorLabel, gbc);

        gbc.gridy = 7;
        gbc.gridwidth = 2;
        JButton modificarButton = new JButton("Modificar Cita");
        add(modificarButton, gbc);

        // modificarButton con enter
        getRootPane().setDefaultButton(modificarButton);

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validarCita();
            }
        });
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton menuPrincipalButton = new JButton("Menú Principal");
        JButton regresarButton = new JButton("Regresar");
        bottomPanel.add(menuPrincipalButton);
        bottomPanel.add(regresarButton);

        gbc.gridy = 9;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(bottomPanel, gbc);

        // Evento para botón "Menú Principal"
        menuPrincipalButton.addActionListener(e -> {
            new Inicio.PortadaFrame().setVisible(true);
            dispose();
        });

        // Evento para botón "Regresar"
        regresarButton.addActionListener(e -> {
            new InicioFrame().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    private void validarCita() {
        String nombre = nombreField.getText();
        String id = idField.getText();
        int dia = (int) diaBox.getSelectedItem();
        int mes = mesBox.getSelectedIndex() + 1;
        int año = (int) añoBox.getSelectedItem();

        if (!ValidacionesCita.esNombreValido(nombre)) {
            errorLabel.setText("Nombre inválido (Solo letras)");
            return;
        }
        if (!ValidacionesCita.esIdValido(id)) {
            errorLabel.setText("ID inválido (Solo números)");
            return;
        }
        if (!ValidacionesCita.esFechaValida(dia, mes, año)) {
            errorLabel.setText("Fecha inválida (Debe ser futura)");
            return;
        }

        errorLabel.setForeground(Color.GREEN);
        errorLabel.setText("Cita modificada correctamente");
    }
}
