package GestionCitas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

public class AgendaCitaFrame extends JFrame {

    private JTextField nombreField, idField;
    private JLabel errorLabel;
    private JComboBox<Integer> diaBox, añoBox;
    private JComboBox<String> mesBox, horaBox, minutoBox;

    public AgendaCitaFrame() {
        setTitle("Agendar Cita");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        setLocationRelativeTo(null);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        JLabel title = new JLabel("Registro de Cita Médica", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        add(title, gbc);

        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        nombreField = new JTextField(12);
        add(nombreField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        idField = new JTextField(12);
        add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Fecha de la Cita:"), gbc);

        gbc.gridx = 1;
        String[] meses = { "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" };
        mesBox = new JComboBox<>(meses);
        diaBox = new JComboBox<>();
        añoBox = new JComboBox<>();

        for (int i = 1; i <= 31; i++)
            diaBox.addItem(i);
        for (int i = LocalDate.now().getYear(); i <= 2030; i++)
            añoBox.addItem(i);

        JPanel fechaPanel = new JPanel();
        fechaPanel.add(diaBox);
        fechaPanel.add(mesBox);
        fechaPanel.add(añoBox);
        add(fechaPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Hora de la Cita:"), gbc);

        // JComboBox para hora
        gbc.gridx = 0;
        String[] horas = { "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21" };
        horaBox = new JComboBox<>(horas);
        // JComboBox para minutos
        gbc.gridx = 1;
        String[] minutos = { "00", "30" };
        minutoBox = new JComboBox<>(minutos);

        JPanel horaPanel = new JPanel();
        horaPanel.add(horaBox);
        horaPanel.add(minutoBox);
        add(horaPanel, gbc);

        errorLabel = new JLabel("", SwingConstants.CENTER);
        errorLabel.setForeground(Color.RED);
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        add(errorLabel, gbc);

        gbc.gridy = 6;
        gbc.gridwidth = 2;
        JButton confirmarButton = new JButton("Confirmar Cita");
        add(confirmarButton, gbc);

        // Confirmar con enter
        getRootPane().setDefaultButton(confirmarButton);

        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validarCita();
            }
        });
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton menuPrincipalButton = new JButton("Menú Principal");
        JButton regresarButton = new JButton("Regresar");
        bottomPanel.add(menuPrincipalButton);
        bottomPanel.add(regresarButton);

        gbc.gridy = 9;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(bottomPanel, gbc);

        // Evento para botón "Menú Principal"
        menuPrincipalButton.addActionListener(e -> {
            new Inicio.PortadaFrame().setVisible(true);
            dispose();
        });

        // Evento para botón "Regresar"
        regresarButton.addActionListener(e -> {
            new InicioFrame().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    private void validarCita() {
        String nombre = nombreField.getText();
        String id = idField.getText();
        int dia = (int) diaBox.getSelectedItem();
        int mes = mesBox.getSelectedIndex() + 1;
        int año = (int) añoBox.getSelectedItem();
        String hora = (String) horaBox.getSelectedItem();
        String minuto = (String) minutoBox.getSelectedItem();

        if (!ValidacionesCita.esNombreValido(nombre)) {
            errorLabel.setText("Nombre inválido (Solo letras)");
            return;
        }
        if (!ValidacionesCita.esIdValido(id)) {
            errorLabel.setText("ID inválido (Solo números)");
            return;
        }
        if (!ValidacionesCita.esFechaValida(dia, mes, año)) {
            errorLabel.setText("Fecha inválida (Debe ser futura)");
            return;
        }

        // Validar hora y minuto seleccionados
        int horaInt = Integer.parseInt(hora);
        int minutoInt = Integer.parseInt(minuto);

        // Rango de horario
        if ((horaInt >= 8 && horaInt <= 14 && minutoInt != 0 && minutoInt != 30) ||
                (horaInt >= 15 && horaInt <= 21 && minutoInt != 0 && minutoInt != 30)) {
            errorLabel.setText("Horario no válido. Seleccione horas de 30 minutos.");
            return;
        }

        errorLabel.setForeground(Color.GREEN);
        errorLabel.setText("Cita registrada correctamente");
    }
}
