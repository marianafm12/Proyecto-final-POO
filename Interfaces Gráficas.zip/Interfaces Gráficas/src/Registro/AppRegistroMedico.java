package Registro;

public class AppRegistroMedico {
    public static void main(String[] args) {
        new LoginFrame();
    }
}
