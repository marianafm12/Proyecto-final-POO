package Emergencias;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LlamadaEmergencia extends JFrame {

    private JTextField NombrePaciente;
    private JTextField IDPaciente;
    private JTextField Ubicacion;
    private JComboBox<String> TipoDeEmergencia;
    private JRadioButton Nivel1, Nivel2, Nivel3, Nivel4, Nivel5;
    private ButtonGroup Gravedad;
    private JTextArea Descripcion;
    private JLabel errorLabel;

    public LlamadaEmergencia() {
        setTitle("Emergencias UDLAP");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        setLocationRelativeTo(null);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título del formulario
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel titleLabel = new JLabel("Formulario de Emergencia", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel, gbc);

        // Información Paciente (Como primera instancia es opcional)
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Nombre del Paciente:"), gbc);
        gbc.gridx = 1;
        NombrePaciente = new JTextField(20);
        add(NombrePaciente, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("ID del Paciente"), gbc);
        gbc.gridx = 1;
        IDPaciente = new JTextField(5);
        add(IDPaciente, gbc);

        // Campo de ubicación
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Ubicación:"), gbc);
        gbc.gridx = 1;
        Ubicacion = new JTextField(20);
        add(Ubicacion, gbc);

        // Tipo de emergencia (ComboBox)
        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Tipo de emergencia:"), gbc);
        gbc.gridx = 1;
        String[] emergencyTypes = { "Caída/Golpe", "Corte", "Quemadura", "Atragantamiento", "Intoxicación Alimentaria",
                "Accidente Eléctrico", "Accidente Deportivo", "Accidente Automovilístico" };
        TipoDeEmergencia = new JComboBox<>(emergencyTypes);
        add(TipoDeEmergencia, gbc);

        // Gravedad de la emergencia (RadioButtons que simulan “círculos”)
        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("Gravedad:"), gbc);
        gbc.gridx = 1;
        JPanel severityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        Nivel1 = new JRadioButton("Rojo");
        Nivel2 = new JRadioButton("Naranja");
        Nivel3 = new JRadioButton("Amarillo");
        Nivel4 = new JRadioButton("Verde");
        Nivel5 = new JRadioButton("Azul");
        Gravedad = new ButtonGroup();
        Gravedad.add(Nivel1);
        Gravedad.add(Nivel2);
        Gravedad.add(Nivel3);
        Gravedad.add(Nivel4);
        Gravedad.add(Nivel5);
        severityPanel.add(Nivel1);
        severityPanel.add(Nivel2);
        severityPanel.add(Nivel3);
        severityPanel.add(Nivel4);
        severityPanel.add(Nivel5);
        add(severityPanel, gbc);

        // Descripción
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        add(new JLabel("Descripción:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        JTextArea Descripcion = new JTextArea(8, 20);
        JScrollPane scrollPane = new JScrollPane(Descripcion);
        add(scrollPane, gbc);

        // Etiqueta para mostrar errores o confirmaciones
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        errorLabel = new JLabel("", SwingConstants.CENTER);
        errorLabel.setForeground(Color.RED);
        add(errorLabel, gbc);

        // Botón para registrar la emergencia
        gbc.gridy = 8;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE;
        JButton submitButton = new JButton("Registrar Emergencia");
        add(submitButton, gbc);
        getRootPane().setDefaultButton(submitButton);

        // Guarde el reporte con enter
        getRootPane().setDefaultButton(submitButton);

        // Acción del botón
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validarFormulario();
            }
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton menuPrincipalButton = new JButton("Menú Principal");
        JButton regresarButton = new JButton("Regresar");
        bottomPanel.add(menuPrincipalButton);
        bottomPanel.add(regresarButton);

        gbc.gridy = 9;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(bottomPanel, gbc);

        // Evento para botón "Menú Principal"
        menuPrincipalButton.addActionListener(e -> {
            new Inicio.PortadaFrame().setVisible(true);
            dispose();
        });

        // Evento para botón "Regresar"
        regresarButton.addActionListener(e -> {
            new Inicio.MenuMedicosFrame().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    private void validarFormulario() {
        String ubicacion = Ubicacion.getText().trim();
        String descripcion = Descripcion.getText().trim();

        if (ubicacion.isEmpty()) {
            errorLabel.setForeground(Color.RED);
            errorLabel.setText("La ubicación es obligatoria.");
            return;
        }
        if (descripcion.isEmpty()) {
            errorLabel.setForeground(Color.RED);
            errorLabel.setText("La descripción es obligatoria.");
            return;
        }
        if (!Nivel1.isSelected() && !Nivel2.isSelected() && !Nivel3.isSelected() && !Nivel4.isSelected()
                && !Nivel5.isSelected()) {
            errorLabel.setForeground(Color.RED);
            errorLabel.setText("Debe seleccionar la gravedad de la emergencia.");
            return;
        }

        errorLabel.setForeground(Color.GREEN);
        errorLabel.setText("Emergencia registrada correctamente.");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LlamadaEmergencia());
    }
}
