package Emergencias;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

public class AccidenteFrame extends JFrame {

    private JTextField nombrePacienteField, apellidosPacienteField, idPacienteField, correoPacienteField,
            telefonoPacienteField;
    private JTextField nombreContactoField, apellidosContactoField, idContactoField, correoContactoField,
            telefonoContactoField;
    private JTextField presionArterialField, ritmoCardiacoField, ritmoRespiratorioField;
    private JTextArea descripcionAccidenteArea, observacionesArea;
    private JComboBox<String> mesAccidenteBox, diaAccidenteBox, añoAccidenteBox, horaAccidenteBox, minutoAccidenteBox;
    private JComboBox<String> generoPacienteBox;
    private JRadioButton alertaRadioButton, conscienteRadioButton, inconscienteRadioButton;
    private ButtonGroup conscienciaGroup;

    public AccidenteFrame() {
        setTitle("Formulario de Accidente");
        setSize(800, 1000);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        setLocationRelativeTo(null);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel title = new JLabel("Formulario de Accidente", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        add(title, gbc);

        // Sección 1: Fecha del accidente y hora
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(new JLabel("*Fecha del Accidente:"), gbc);

        gbc.gridx = 1;
        String[] meses = { "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" };
        mesAccidenteBox = new JComboBox<>(meses);
        diaAccidenteBox = new JComboBox<>();
        añoAccidenteBox = new JComboBox<>();
        horaAccidenteBox = new JComboBox<>();
        minutoAccidenteBox = new JComboBox<>();

        for (int i = 1; i <= 31; i++)
            diaAccidenteBox.addItem(String.valueOf(i));
        for (int i = 2023; i <= 2030; i++)
            añoAccidenteBox.addItem(String.valueOf(i));
        for (int i = 0; i < 24; i++)
            horaAccidenteBox.addItem(String.format("%02d", i));
        for (int i = 0; i < 60; i++)
            minutoAccidenteBox.addItem(String.format("%02d", i));

        JPanel fechaPanel = new JPanel();
        fechaPanel.add(diaAccidenteBox);
        fechaPanel.add(mesAccidenteBox);
        fechaPanel.add(añoAccidenteBox);
        fechaPanel.add(horaAccidenteBox);
        fechaPanel.add(minutoAccidenteBox);
        add(fechaPanel, gbc);

        // Sección 2: Información del paciente
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        add(new JLabel("*Nombre del Paciente:"), gbc);
        gbc.gridx = 1;
        nombrePacienteField = new JTextField(12);
        add(nombrePacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("*Apellidos del Paciente:"), gbc);
        gbc.gridx = 1;
        apellidosPacienteField = new JTextField(12);
        add(apellidosPacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("*ID del Paciente:"), gbc);
        gbc.gridx = 1;
        idPacienteField = new JTextField(12);
        add(idPacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(new JLabel("*Correo del Paciente:"), gbc);
        gbc.gridx = 1;
        correoPacienteField = new JTextField(12);
        add(correoPacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        add(new JLabel("*Teléfono del Paciente:"), gbc);
        gbc.gridx = 1;
        telefonoPacienteField = new JTextField(12);
        add(telefonoPacienteField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        add(new JLabel("*Género del Paciente:"), gbc);
        gbc.gridx = 1;
        String[] generos = { "Masculino", "Femenino", "Otro" };
        generoPacienteBox = new JComboBox<>(generos);
        add(generoPacienteBox, gbc);

        // Sección 3: Información del contacto de emergencia
        gbc.gridx = 0;
        gbc.gridy = 8;
        add(new JLabel("Nombre del Contacto:"), gbc);
        gbc.gridx = 1;
        nombreContactoField = new JTextField(12);
        add(nombreContactoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 9;
        add(new JLabel("Apellidos del Contacto:"), gbc);
        gbc.gridx = 1;
        apellidosContactoField = new JTextField(12);
        add(apellidosContactoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 10;
        add(new JLabel("ID del Contacto:"), gbc);
        gbc.gridx = 1;
        idContactoField = new JTextField(12);
        add(idContactoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 11;
        add(new JLabel("Correo del Contacto:"), gbc);
        gbc.gridx = 1;
        correoContactoField = new JTextField(12);
        add(correoContactoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 12;
        add(new JLabel("Teléfono del Contacto:"), gbc);
        gbc.gridx = 1;
        telefonoContactoField = new JTextField(12);
        add(telefonoContactoField, gbc);

        // Sección 4: Signos vitales
        gbc.gridx = 0;
        gbc.gridy = 13;
        add(new JLabel("*Presión Arterial:"), gbc);
        gbc.gridx = 1;
        presionArterialField = new JTextField(12);
        add(presionArterialField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 14;
        add(new JLabel("*Ritmo Cardíaco:"), gbc);
        gbc.gridx = 1;
        ritmoCardiacoField = new JTextField(12);
        add(ritmoCardiacoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 15;
        add(new JLabel("*Ritmo Respiratorio:"), gbc);
        gbc.gridx = 1;
        ritmoRespiratorioField = new JTextField(12);
        add(ritmoRespiratorioField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 16;
        add(new JLabel("*Consciencia del Paciente:"), gbc);

        gbc.gridx = 1;
        alertaRadioButton = new JRadioButton("Alerta");
        conscienteRadioButton = new JRadioButton("Consciente");
        inconscienteRadioButton = new JRadioButton("Inconsciente");

        conscienciaGroup = new ButtonGroup();
        conscienciaGroup.add(alertaRadioButton);
        conscienciaGroup.add(conscienteRadioButton);
        conscienciaGroup.add(inconscienteRadioButton);

        JPanel conscienciaPanel = new JPanel();
        conscienciaPanel.add(alertaRadioButton);
        conscienciaPanel.add(conscienteRadioButton);
        conscienciaPanel.add(inconscienteRadioButton);
        add(conscienciaPanel, gbc);

        // Descripción del Accidente y Observaciones
        gbc.gridx = 0;
        gbc.gridy = 17;
        add(new JLabel("*Descripción del Accidente:"), gbc);

        gbc.gridx = 1;
        descripcionAccidenteArea = new JTextArea(4, 20);
        JScrollPane descripcionScroll = new JScrollPane(descripcionAccidenteArea);
        add(descripcionScroll, gbc);

        gbc.gridx = 0;
        gbc.gridy = 18;
        add(new JLabel("Observaciones Adicionales:"), gbc);

        gbc.gridx = 1;
        observacionesArea = new JTextArea(4, 20);
        JScrollPane observacionesScroll = new JScrollPane(observacionesArea);
        add(observacionesScroll, gbc);

        // Confirmación
        gbc.gridx = 0;
        gbc.gridy = 19;
        gbc.gridwidth = 2;
        JButton confirmarButton = new JButton("Confirmar Accidente");
        add(confirmarButton, gbc);

        // Confirmar con enter
        getRootPane().setDefaultButton(confirmarButton);

        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validarFormulario();
            }
        });
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton menuPrincipalButton = new JButton("Menú Principal");
        JButton regresarButton = new JButton("Regresar");
        bottomPanel.add(menuPrincipalButton);
        bottomPanel.add(regresarButton);

        gbc.gridy = 20;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(bottomPanel, gbc);

        // Evento para botón "Menú Principal"
        menuPrincipalButton.addActionListener(e -> {
            new Inicio.PortadaFrame().setVisible(true);
            dispose();
        });

        // Evento para botón "Regresar"
        regresarButton.addActionListener(e -> {
            new Inicio.MenuMedicosFrame().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    private void validarFormulario() {
        // Obtener fecha del accidente
        int dia = Integer.parseInt((String) diaAccidenteBox.getSelectedItem());
        int mes = mesAccidenteBox.getSelectedIndex() + 1;
        int año = Integer.parseInt((String) añoAccidenteBox.getSelectedItem());
        int hora = Integer.parseInt((String) horaAccidenteBox.getSelectedItem());
        int minuto = Integer.parseInt((String) minutoAccidenteBox.getSelectedItem());

        // Verificar fecha
        if (!isDateValid(dia, mes, año, hora, minuto)) {
            JOptionPane.showMessageDialog(this,
                    "La fecha del accidente no puede ser menor a la fecha actual.");
            return;
        }

        // Validación de campos vacíos y contenido inválido
        if (nombrePacienteField.getText().isEmpty() || apellidosPacienteField.getText().isEmpty()
                || idPacienteField.getText().isEmpty() ||
                correoPacienteField.getText().isEmpty() || telefonoPacienteField.getText().isEmpty()
                || presionArterialField.getText().isEmpty() ||
                ritmoCardiacoField.getText().isEmpty() || ritmoRespiratorioField.getText().isEmpty()
                || conscienciaGroup.getSelection() == null) {
            JOptionPane.showMessageDialog(this, "Todos los campos marcados con * deben ser llenados correctamente.");
            return;
        }

        // Validación de formato de datos
        if (!nombrePacienteField.getText().matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(this, "El nombre solo debe contener letras.");
            return;
        }

        if (!apellidosPacienteField.getText().matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(this, "El apellido solo debe contener letras.");
            return;
        }

        if (!idPacienteField.getText().matches("[0-9]+")) {
            JOptionPane.showMessageDialog(this, "El ID debe contener solo números.");
            return;
        }

        if (!correoPacienteField.getText().contains("@")) {
            JOptionPane.showMessageDialog(this, "El correo debe contener un '@'.");
            return;
        }

        try {
            Integer.parseInt(telefonoPacienteField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El teléfono debe ser un valor numérico.");
            return;
        }

        // Si pasa todas las validaciones
        JOptionPane.showMessageDialog(this, "Formulario enviado correctamente.");
    }

    private boolean isDateValid(int dia, int mes, int año, int hora, int minuto) {
        LocalDate currentDate = LocalDate.now();
        LocalDate selectedDate = LocalDate.of(año, mes, dia);

        // Verificar si la fecha seleccionada es menor que la fecha actual
        if (selectedDate.isBefore(currentDate)) {
            return false;
        }

        return true;
    }

    public static void main(String[] args) {
        new AccidenteFrame();
    }
}