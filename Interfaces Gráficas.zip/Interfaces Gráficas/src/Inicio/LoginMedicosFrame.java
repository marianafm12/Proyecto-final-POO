package Inicio;

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class LoginMedicosFrame extends JFrame {

    public LoginMedicosFrame() {
        setTitle("Inicio de sesión Médicos UDLAP");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        setLocationRelativeTo(null);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Etiqueta y campo para el ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("ID:"), gbc);

        gbc.gridx = 1;
        JTextField idField = new JTextField(15);
        add(idField, gbc);

        // Etiqueta y campo para la contraseña
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Contraseña:"), gbc);

        gbc.gridx = 1;
        JPasswordField passwordField = new JPasswordField(15);
        add(passwordField, gbc);

        // Botón de Login
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        JButton loginButton = new JButton("Iniciar Sesión");
        add(loginButton, gbc);
        // Hace que al presionar enter sea el equivalente a presionar loginButton
        getRootPane().setDefaultButton(loginButton);

        // Botón de Recuperar Contraseña
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JButton recoverButton = new JButton("Recuperar Contraseña");
        add(recoverButton, gbc);

        // Acción del botón Login
        loginButton.addActionListener((ActionEvent e) -> {
            String idText = idField.getText();
            String password = new String(passwordField.getPassword());

            try {
                int id = Integer.parseInt(idText);

                // Lógica de validación
                // Rangos Ajustables
                if (((id >= 2000 && id <= 6000))
                        && password.equals("medicos")) {
                    // Si la validación es correcta, abre el menú principal
                    new MenuMedicosFrame();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Credenciales incorrectas",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID inválido",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Acción botón recuperar contraseña
        recoverButton.addActionListener(e -> {
            new RecuperarContrasenaFrame();
            dispose();
        });

        setVisible(true);
    }
}
