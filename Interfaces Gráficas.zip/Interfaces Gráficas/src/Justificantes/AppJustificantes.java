//Pacientes y Médicos
package Justificantes;

public class AppJustificantes {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new InicioFrame());
    }
}
