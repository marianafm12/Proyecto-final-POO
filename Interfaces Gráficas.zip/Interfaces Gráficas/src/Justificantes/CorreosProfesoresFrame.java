package Justificantes;

import javax.swing.*;
import java.awt.*;

public class CorreosProfesoresFrame extends JFrame {
    private JComboBox<Integer> cantidadProfesoresBox;
    private JPanel correosPanel;
    private JButton enviarBtn;

    public CorreosProfesoresFrame() {
        setTitle("Agregar Correos de Profesores");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Cantidad de profesores:"));
        cantidadProfesoresBox = new JComboBox<>();
        for (int i = 1; i <= 12; i++) {
            cantidadProfesoresBox.addItem(i);
        }
        topPanel.add(cantidadProfesoresBox);

        correosPanel = new JPanel();
        correosPanel.setLayout(new GridLayout(12, 1));
        actualizarCamposCorreos(1);

        cantidadProfesoresBox.addActionListener(e -> {
            int cantidad = (int) cantidadProfesoresBox.getSelectedItem();
            actualizarCamposCorreos(cantidad);
        });

        enviarBtn = new JButton("Enviar Justificante");
        enviarBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Justificante enviado a los profesores.", "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
            dispose();
        });

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(correosPanel), BorderLayout.CENTER);
        add(enviarBtn, BorderLayout.SOUTH);
        setVisible(true);
    }

    private void actualizarCamposCorreos(int cantidad) {
        correosPanel.removeAll();
        correosPanel.setLayout(new GridLayout(cantidad, 1));
        for (int i = 0; i < cantidad; i++) {
            correosPanel.add(new JTextField("Correo profesor " + (i + 1) + ": "));
        }
        correosPanel.revalidate();
        correosPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CorreosProfesoresFrame::new);
    }
}
