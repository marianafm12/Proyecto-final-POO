package Justificantes;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class FormularioJustificanteFrame extends JFrame {
    private JTextField motivoField, diasField;
    private JButton subirArchivoBtn, siguienteBtn;
    private File justificanteFile;

    public FormularioJustificanteFrame() {
        setTitle("Solicitud de Justificante Médico");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Configuración para los componentes
        JLabel motivoLabel = new JLabel("Motivo:");
        JLabel diasLabel = new JLabel("Días de Ausencia:");
        motivoField = new JTextField(20);
        diasField = new JTextField(20);
        subirArchivoBtn = new JButton("Subir Justificante (PDF)");
        siguienteBtn = new JButton("Siguiente");

        // Añadir acción al botón "Subir Justificante"
        subirArchivoBtn.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                justificanteFile = fileChooser.getSelectedFile();
                JOptionPane.showMessageDialog(this, "Archivo seleccionado: " + justificanteFile.getName());
            }
        });

        // Añadir acción al botón "Siguiente"
        siguienteBtn.addActionListener(e -> {
            new CorreosProfesoresFrame();
            dispose();
        });

        // Añadir el botón "Menú Principal" y "Regresar"
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton menuPrincipalButton = new JButton("Menú Principal");
        JButton regresarButton = new JButton("Regresar");
        bottomPanel.add(menuPrincipalButton);
        bottomPanel.add(regresarButton);

        // Evento para el botón "Menú Principal"
        menuPrincipalButton.addActionListener(e -> {
            new Inicio.PortadaFrame().setVisible(true);
            dispose();
        });

        // Evento para el botón "Regresar"
        regresarButton.addActionListener(e -> {
            new Inicio.MenuPacientesFrame().setVisible(true);
            dispose();
        });

        // Estableciendo restricciones para el layout con GridBagConstraints
        // Título del sistema
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 5, 5, 5);
        JLabel titleLabel = new JLabel("Solicitud Justificantes Médicos UDLAP", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, gbc);

        // Motivo
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(motivoLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(motivoField, gbc);

        // Días de Ausencia
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(diasLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(diasField, gbc);

        // Subir archivo
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(subirArchivoBtn, gbc);

        // Siguiente
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(siguienteBtn, gbc);

        // Añadiendo los botones al panel inferior con GridBagConstraints
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(bottomPanel, gbc);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FormularioJustificanteFrame::new);
    }
}
