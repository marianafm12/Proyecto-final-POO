package Justificantes;

import javax.swing.*;
import java.awt.*;

public class DiagnosticoMedicoFrame extends JFrame {
    private JTextArea diagnosticoArea, observacionesArea;
    private JButton guardarBtn;

    public DiagnosticoMedicoFrame() {
        setTitle("Generar Diagnóstico Médico");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 1));

        // Panel de Diagnóstico
        JPanel panelDiagnostico = new JPanel(new BorderLayout());
        JLabel diagnosticoLabel = new JLabel("Diagnóstico:");
        diagnosticoArea = new JTextArea(5, 20);
        panelDiagnostico.add(diagnosticoLabel, BorderLayout.NORTH);
        panelDiagnostico.add(new JScrollPane(diagnosticoArea), BorderLayout.CENTER);

        // Panel de Observaciones
        JPanel panelObservaciones = new JPanel(new BorderLayout());
        JLabel observacionesLabel = new JLabel("Observaciones:");
        observacionesArea = new JTextArea(5, 20);
        panelObservaciones.add(observacionesLabel, BorderLayout.NORTH);
        panelObservaciones.add(new JScrollPane(observacionesArea), BorderLayout.CENTER);

        // Botón de Guardado
        guardarBtn = new JButton("Guardar Diagnóstico");
        guardarBtn.addActionListener(e -> {
            String diagnostico = diagnosticoArea.getText();
            String observaciones = observacionesArea.getText();
            if (!diagnostico.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Diagnóstico Guardado:\n" + diagnostico + "\nObservaciones:\n" + observaciones, "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "El campo de diagnóstico no puede estar vacío.", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        // Agregar elementos a la ventana
        add(panelDiagnostico);
        add(panelObservaciones);
        add(guardarBtn);

        setVisible(true);
    }

    // Método main para ejecución independiente
    public static void main(String[] args) {
        SwingUtilities.invokeLater(DiagnosticoMedicoFrame::new);
    }
}