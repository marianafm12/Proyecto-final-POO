package Justificantes;

import javax.swing.*;
import java.awt.*;

public class PlantillaJustificanteFrame extends JFrame {
    private JTextField centroMedicoField, doctorField, cedulaField, pacienteField, dniField, horaField;
    private JTextArea diagnosticoArea;
    private JComboBox<String> diaBox, mesBox, anioBox;
    private JButton guardarBtn;
    private JLabel errorLabel;

    public PlantillaJustificanteFrame(String paciente) {
        setTitle("Plantilla de Justificante Médico");
        setLayout(new GridLayout(11, 2));
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Campos para el centro médico y doctor
        centroMedicoField = new JTextField();
        doctorField = new JTextField();
        cedulaField = new JTextField();

        // Campos para el paciente
        pacienteField = new JTextField(paciente);
        dniField = new JTextField();

        // Campos para la fecha
        String[] dias = new String[31];
        for (int i = 1; i <= 31; i++) {
            dias[i - 1] = String.valueOf(i);
        }

        String[] meses = {
                "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
        };

        String[] anios = new String[100];
        int actualYear = java.time.Year.now().getValue();
        for (int i = 0; i < 100; i++) {
            anios[i] = String.valueOf(actualYear - i);
        }

        diaBox = new JComboBox<>(dias);
        mesBox = new JComboBox<>(meses);
        anioBox = new JComboBox<>(anios);

        // Hora de atención
        horaField = new JTextField();

        // Diagnóstico
        diagnosticoArea = new JTextArea(5, 20);

        // Botón para guardar
        guardarBtn = new JButton("Guardar Justificante");

        // Mensajes de error
        errorLabel = new JLabel("");
        errorLabel.setForeground(Color.RED);

        add(new JLabel("Centro Médico:"));
        add(centroMedicoField);

        add(new JLabel("Doctor/a:"));
        add(doctorField);

        add(new JLabel("Cédula Profesional:"));
        add(cedulaField);

        add(new JLabel("Paciente:"));
        add(pacienteField);

        add(new JLabel("ID:"));
        add(dniField);

        add(new JLabel("Fecha de Atención:"));
        JPanel fechaPanel = new JPanel();
        fechaPanel.add(diaBox);
        fechaPanel.add(mesBox);
        fechaPanel.add(anioBox);
        add(fechaPanel);

        add(new JLabel("Hora de Atención:"));
        add(horaField);

        add(new JLabel("Diagnóstico y Observaciones:"));
        add(new JScrollPane(diagnosticoArea));

        add(new JLabel("Firma del médico:"));
        add(new JTextField());

        add(errorLabel);
        add(guardarBtn);

        // Enter guarda
        getRootPane().setDefaultButton(guardarBtn);

        // Verificar que esté lleno el formulario
        guardarBtn.addActionListener(e -> {
            // Verifica que ninguno de los campos esté vacío
            if (centroMedicoField.getText().trim().isEmpty() ||
                    doctorField.getText().trim().isEmpty() ||
                    cedulaField.getText().trim().isEmpty() ||
                    pacienteField.getText().trim().isEmpty() ||
                    dniField.getText().trim().isEmpty() ||
                    horaField.getText().trim().isEmpty() ||
                    diagnosticoArea.getText().trim().isEmpty()) {
                errorLabel.setText("Falta información por llenar.");
            } else {
                // Si todo está lleno, se guarda
                errorLabel.setText("");
                JOptionPane.showMessageDialog(
                        this,
                        "Justificante guardado correctamente.",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);
                dispose();
            }
        });

        // Justificante"
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton menuPrincipalButton = new JButton("Menú Principal");
        JButton regresarButton = new JButton("Regresar");
        bottomPanel.add(menuPrincipalButton);
        bottomPanel.add(regresarButton);

        add(bottomPanel);

        // Evento para el botón "Menú Principal"
        menuPrincipalButton.addActionListener(e -> {
            new Inicio.PortadaFrame().setVisible(true);
            dispose();
        });

        // Evento para el botón "Regresar"
        regresarButton.addActionListener(e -> {
            new Inicio.MenuMedicosFrame().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PlantillaJustificanteFrame("Paciente Ejemplo"));
    }
}
