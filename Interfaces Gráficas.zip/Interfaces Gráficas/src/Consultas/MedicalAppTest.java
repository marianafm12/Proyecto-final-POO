package Consultas;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class MedicalAppTest {
    private PatientForm patientForm;

    @Before
    public void setUp() {
        patientForm = new PatientForm("Dr. Pérez");
    }

    @Test
    public void testValidIDPaciente() {
        assertTrue(patientForm.isInteger("12345"));
        assertFalse(patientForm.isInteger("abc123"));
        assertFalse(patientForm.isInteger("12.5"));
    }

    @Test
    public void testValidNombrePaciente() {
        assertTrue(patientForm.isText("Juan Pérez"));
        assertFalse(patientForm.isText("Juan123"));
        assertFalse(patientForm.isText("12345"));
    }

    @Test
    public void testValidEdad() {
        assertTrue(patientForm.isInteger("30"));
        assertFalse(patientForm.isInteger("-5"));
        assertFalse(patientForm.isInteger("edad"));
    }

    @Test
    public void testValidEmail() {
        assertTrue(patientForm.isValidEmail("doctor@gmail.com"));
        assertFalse(patientForm.isValidEmail("doctor.com"));
        assertFalse(patientForm.isValidEmail("doctor@.com"));
    }

    @Test
    public void testValidDate() {
        assertTrue(patientForm.isValidDate("15/03/2025"));
        assertFalse(patientForm.isValidDate("32/13/2025"));
        assertFalse(patientForm.isValidDate("15-03-2025"));
    }
}
