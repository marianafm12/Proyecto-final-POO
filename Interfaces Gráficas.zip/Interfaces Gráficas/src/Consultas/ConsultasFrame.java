package Consultas;

import javax.swing.*;
import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ConsultasFrame {
    public static void launchApp() {
        SwingUtilities.invokeLater(() -> new PatientForm("Medico"));
    }
}

class PatientForm extends JFrame {
    private JTextField IDPacienteField, NombrePacienteField, ageField, emailField, symptomsField, medsField,
            diagnosisField, IDExpedienteMedicoField, dateField, lastVisitField, symptomStartField;
    private JTextArea prescriptionField;
    private JButton saveButton;

    public PatientForm(String medico) {
        setTitle("Formulario del Paciente - Dr. " + medico);
        setSize(500, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        JLabel headerLabel = new JLabel("Formulario del Paciente", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(headerLabel, gbc);

        row++;
        gbc.gridwidth = 1;

        // ID Paciente
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("ID Paciente:"), gbc);
        gbc.gridx = 1;
        IDPacienteField = new JTextField(15);
        add(IDPacienteField, gbc);

        row++;
        // Nombre del Paciente
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Nombre Completo del Paciente:"), gbc);
        gbc.gridx = 1;
        NombrePacienteField = new JTextField(15);
        add(NombrePacienteField, gbc);

        row++;
        // Edad
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Edad:"), gbc);
        gbc.gridx = 1;
        ageField = new JTextField(15);
        add(ageField, gbc);

        row++;
        // Correo Electrónico
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Correo Electrónico:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(15);
        add(emailField, gbc);

        row++;
        // Síntomas
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Síntomas:"), gbc);
        gbc.gridx = 1;
        symptomsField = new JTextField(15);
        add(symptomsField, gbc);

        row++;
        // Medicamentos
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Medicamento(s) administrado(s):"), gbc);
        gbc.gridx = 1;
        medsField = new JTextField(15);
        add(medsField, gbc);

        row++;
        // Diagnóstico
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Diagnóstico:"), gbc);
        gbc.gridx = 1;
        diagnosisField = new JTextField(15);
        add(diagnosisField, gbc);

        row++;
        // ID Expediente Médico
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("ID Expediente Médico:"), gbc);
        gbc.gridx = 1;
        IDExpedienteMedicoField = new JTextField(15);
        add(IDExpedienteMedicoField, gbc);

        row++;
        // Fecha
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Fecha (dd/mm/aaaa):"), gbc);
        gbc.gridx = 1;
        dateField = new JTextField(15);
        add(dateField, gbc);

        row++;
        // Última Consulta
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Última Consulta (dd/mm/aaaa):"), gbc);
        gbc.gridx = 1;
        lastVisitField = new JTextField(15);
        add(lastVisitField, gbc);

        row++;
        // Fecha de inicio de síntomas
        gbc.gridx = 0;
        gbc.gridy = row;
        add(new JLabel("Fecha de inicio de síntomas (dd/mm/aaaa):"), gbc);
        gbc.gridx = 1;
        symptomStartField = new JTextField(15);
        add(symptomStartField, gbc);

        row++;
        // Receta Médica (área de texto con scroll)
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(new JLabel("Receta Médica:"), gbc);
        gbc.gridx = 1;
        prescriptionField = new JTextArea(5, 15);
        JScrollPane scrollPane = new JScrollPane(prescriptionField);
        add(scrollPane, gbc);

        row++;
        // Panel de botones
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        saveButton = new JButton("Guardar Datos");
        buttonPanel.add(saveButton);
        add(buttonPanel, gbc);

        // Equivalente al saveButton con enter
        getRootPane().setDefaultButton(saveButton);

        // Acción para guardar datos
        saveButton.addActionListener(e -> {
            if (validateFields()) {
                showConfirmationScreen();
            }
        });

        row++;
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton menuPrincipalButton = new JButton("Menú Principal");
        JButton regresarButton = new JButton("Regresar");
        bottomPanel.add(menuPrincipalButton);
        bottomPanel.add(regresarButton);

        gbc.gridy = row;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(bottomPanel, gbc);

        // Evento para botón "Menú Principal"
        menuPrincipalButton.addActionListener(e -> {
            new Inicio.PortadaFrame().setVisible(true);
            dispose();
        });

        // Evento para botón "Regresar"
        regresarButton.addActionListener(e -> {
            new Inicio.MenuMedicosFrame().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    // VALIDACIONES
    public boolean validateFields() {
        StringBuilder errores = new StringBuilder();

        if (IDPacienteField.getText().isEmpty() || NombrePacienteField.getText().isEmpty()
                || ageField.getText().isEmpty() ||
                emailField.getText().isEmpty() || symptomsField.getText().isEmpty() || medsField.getText().isEmpty() ||
                diagnosisField.getText().isEmpty() || IDExpedienteMedicoField.getText().isEmpty()
                || dateField.getText().isEmpty() ||
                lastVisitField.getText().isEmpty() || symptomStartField.getText().isEmpty()
                || prescriptionField.getText().isEmpty()) {
            errores.append("- No puedes dejar campos vacíos.\n");
        }

        if (!isInteger(IDPacienteField.getText()))
            errores.append("- El ID del paciente debe ser un número entero.\n");
        if (!isInteger(IDExpedienteMedicoField.getText()))
            errores.append("- El ID del expediente médico debe ser un número entero.\n");
        if (!isInteger(ageField.getText()))
            errores.append("- La edad debe ser un número entero.\n");

        if (!isText(NombrePacienteField.getText()))
            errores.append("- El nombre del paciente solo debe contener letras.\n");
        if (!isText(diagnosisField.getText()))
            errores.append("- El diagnóstico solo debe contener letras.\n");

        if (!isValidEmail(emailField.getText()))
            errores.append("- Ingresa un correo válido (ejemplo@dominio.com).\n");

        if (!isValidDate(dateField.getText()))
            errores.append("- La fecha debe estar en formato dd/MM/yyyy.\n");
        if (!isValidDate(lastVisitField.getText()))
            errores.append("- La fecha de última consulta debe estar en formato dd/MM/yyyy.\n");
        if (!isValidDate(symptomStartField.getText()))
            errores.append("- La fecha de inicio de síntomas debe estar en formato dd/MM/yyyy.\n");

        if (errores.length() > 0) {
            showError("Errores detectados:\n" + errores.toString());
            return false;
        }

        return true;
    }

    public boolean isInteger(String str) {
        return str.matches("\\d+");
    }

    public boolean isText(String str) {
        return str.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+");
    }

    public boolean isValidEmail(String email) {
        return email.matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,6}$");
    }

    public boolean isValidDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        try {
            sdf.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showConfirmationScreen() {
        JFrame confirmationFrame = new JFrame("Confirmación de Datos");
        confirmationFrame.setSize(400, 500);
        confirmationFrame.setLayout(new BorderLayout());

        String email = emailField.getText();

        JTextArea confirmationText = new JTextArea();
        confirmationText.setEditable(false);
        confirmationText.setText("CONFIRMACIÓN DE DATOS:\n\n"
                + "ID Paciente: " + IDPacienteField.getText() + "\n"
                + "Nombre del Paciente: " + NombrePacienteField.getText() + "\n"
                + "Edad: " + ageField.getText() + "\n"
                + "Correo Electrónico: " + email + "\n"
                + "Síntomas: " + symptomsField.getText() + "\n"
                + "Medicamentos: " + medsField.getText() + "\n"
                + "Diagnóstico: " + diagnosisField.getText() + "\n"
                + "ID Expediente Médico: " + IDExpedienteMedicoField.getText() + "\n"
                + "Fecha: " + dateField.getText() + "\n"
                + "Última Consulta: " + lastVisitField.getText() + "\n"
                + "Fecha de inicio de síntomas: " + symptomStartField.getText() + "\n"
                + "Receta Médica: " + prescriptionField.getText());

        confirmationFrame.add(new JScrollPane(confirmationText), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton confirmButton = new JButton("Confirmar");
        JButton editButton = new JButton("Regresar y Editar");

        buttonPanel.add(confirmButton);
        buttonPanel.add(editButton);
        confirmationFrame.add(buttonPanel, BorderLayout.SOUTH);

        confirmButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(confirmationFrame, "📩 La receta médica ha sido enviada al correo: " + email,
                    "Confirmación", JOptionPane.INFORMATION_MESSAGE);
            confirmationFrame.dispose();
        });

        editButton.addActionListener(e -> confirmationFrame.dispose());

        confirmationFrame.setLocationRelativeTo(null);
        confirmationFrame.setVisible(true);
    }
}
