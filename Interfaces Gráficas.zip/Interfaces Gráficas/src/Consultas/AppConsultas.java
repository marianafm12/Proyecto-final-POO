//Sólo para médicos

package Consultas;

public class AppConsultas {
    public static void main(String[] args) {
        ConsultasFrame.launchApp();
    }
}
